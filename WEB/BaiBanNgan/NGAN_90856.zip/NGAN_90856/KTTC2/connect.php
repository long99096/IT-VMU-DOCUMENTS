<?php 
     //$conn = new PDO("mysql:host=localhost;dbname=hanghoa", 'Student', '123');
    $conn = new PDO("mysql:host=localhost;dbname=hanghoa",'root','');
?>