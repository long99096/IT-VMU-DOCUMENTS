<?php 
     $conn = new PDO("mysql:host=localhost;dbname=hocsinh1", 'Student', '123');
    //$conn = new PDO("mysql:host=localhost;dbname=hocsinh1",'root','');
?>