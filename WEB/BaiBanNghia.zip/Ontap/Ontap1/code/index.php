<?php
	session_start(); 
	if (!isset($_SESSION['user'])) {
		header("Location: login.php");
		exit();
	}
	
	include "connect.php";
	if (isset($_POST['submit'])) {
		$Ten = $_POST['timkiem'];
		if ($Ten == null) {
			$sql = "SELECT * FROM nhanvien";
		}
		else{
			$sql = "SELECT * FROM nhanvien WHERE hoten LIKE '%$Ten%' ";
		}
	}
	else{
		$sql = "SELECT * FROM nhanvien";
	}
	
	$stmt = $conn->prepare($sql);
	$query = $stmt->execute();
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
	<link rel="stylesheet" type="text/css" href="style.css">
	<title>Nhan vien</title>
</head>
<body>
	<header>
		<h1>DANH SACH NHAN VIEN</h1>
		<img src="../image/logo.jpg" class="setpic">
	</header>
	<content>
		<div>
			<form method="POST">
			<label>Ten nhan vien</label>
			<input type="text" name="timkiem">
			<button type="submit" name="submit">Tim kiem</button>
			</form>
			<form action="add_nhanvien.php" method="get">
				<button type="submit" value="themsanpham" name="btn_add">Them nhan vien</button>
			</form>
			<form action="logout.php" method="get">
				<button type="submit" value="dangxuat" name="btn_dangxuat">Dang xuat</button>
			</form>
		</div>

		<div>
			<table class="table-bordered">
				<thead>
				<tr>
					<th>ID</th>
					<th>Ho ten</th>
					<th>Anh</th>
					<th>Ngay sinh</th>
					<th>So dien thoai</th>
					<th>Thao tac</th>
				</tr>
			</thead>


				<?php
					if ($query) {
						$count = 0;
						while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
							?>
							<tr>
								<div>
									<td><?php echo $row['id']; ?></td>
									<td><?php echo $row['hoten']; ?></td>
									<td><img class="setpic" src="../image/<?php echo $row['anhnv'];?>"></td>
									<td><?php echo $row['ngaysinh']; ?></td>
									<td><?php echo $row['dienthoai']; ?></td>
									<td><form action="edit_nhanvien.php" method="get">
										<input type="hidden" name="id" value="<?php echo $row['id']; ?>">
										<button type="submit" name="btnSua" value="sua">Sua</button>
									</form></td>
								</div>
							</t>
							<?php
						}
					}
				?>
			</table>
		</div>
	</content>

	<footer>Vu Quy Nghia 92290</footer>

</body>
</html>