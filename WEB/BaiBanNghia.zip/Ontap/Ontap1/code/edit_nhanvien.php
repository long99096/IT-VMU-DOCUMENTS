<?php
	include('connect.php');
	$id = $_GET['id'];
	$sql1 = "SELECT * FROM nhanvien WHERE id = '$id'";
	$stmt = $conn->prepare($sql1);
	$query = $stmt->execute();
	$result = $stmt->fetch(PDO::FETCH_ASSOC);
	if (!empty($_POST['submit'])) {
		if (!empty($_POST['hoten'])&&isset($_POST['anhnv'])&&isset($_POST['ngaysinh'])&&isset($_POST['dienthoai'])) {
			$hoten = $_POST['hoten'];
			$anhnv = $_POST['anhnv'];
			$ngaysinh = $_POST['ngaysinh'];
			$dienthoai = $_POST['dienthoai'];
			$sql = "UPDATE nhanvien SET hoten= '$hoten', anhnv = '$anhnv', ngaysinh = '$ngaysinh', dienthoai = '$dienthoai' WHERE id = '$id' ";
			$stmt = $conn->prepare($sql);
			$query = $stmt->execute();
			if ($query) {
				header("location:index.php");
			}
			else{
				echo "Sua that bai, vui long thu lai";
			}
		}
	}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Sua nhan vien</title>
</head>
<body>
	<form method="POST">
		<table class="table table-inverse">
			<tbody>
				<tr>
					<td>Ho ten</td>
					<td><input type="text" name="hoten" value="<?php echo $result['hoten'] ?>"></td>
				</tr>

				<tr>
					<td>Anh nv</td>
					<td><input type="text" name="anhnv" value="<?php echo $result['anhnv'] ?>"></td>
				</tr>

				<tr>
					<td>Ngay sinh</td>
					<td><input type="text" name="ngaysinh" value="<?php echo $result['ngaysinh'] ?>"></td>
				</tr>

				<tr>
					<td>So dien thoai</td>
					<td><input type="text" name="dienthoai" value="<?php echo $result['dienthoai'] ?>"></td>
				</tr>
			</tbody>
			<button type="submit" name="submit" value="submit">Luu</button>
		</table>
	</form>
</body>
</html>