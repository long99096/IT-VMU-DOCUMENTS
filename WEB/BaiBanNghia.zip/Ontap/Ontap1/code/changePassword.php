<?php
	include('connect.php');
	session_start();

	if ($_SERVER["REQUEST_METHOD"] == "POST") {
		$username = $_POST['user'];
		$newPassword = $_POST['newPassword'];
		$confirmPassword = $_POST['confirmPassword'];

		if ($newPassword === $confirmPassword) {
			$checkUserSql = "SELECT * FROM login WHERE user = '$username' ";
			$checkUserStmt = $conn->prepare($checkUserSql);
			$checkUserStmt->execute();

			if ($checkUserStmt->rowCount() > 0 ) {
			$updateSql = "UPDATE login SET password = '$newPassword' WHERE user = '$username' ";
			$updateStmt = $conn->prepare($updateSql);
			$updateStmt->execute();

			if ($updateStmt->rowCount() > 0) {
				$message = "Doi mat khau thanh cong";
				header("location: login.php");
				exit();
			}
			else{
				$error = "khong the doi mat khau";
			}
		}	else{
				$error = "Ten dang nhap khong ton tai";
			}
		}else{
			$error = "mat khau xac nhan khong khop";
		}
	}
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Doi mat khau</title>
</head>
<body>
	<div class="container">
		<h2>Doi mat khau</h2>

		<?php if (isset($error)) {
			echo "<div class='alert'>$error</div>";
		}?>
		<?php if (isset($message)) {
			echo "<div class='success'>$message</div>";
		} ?>

		<form action="" method="post">
			<div>
				<label for="user">Ten dang nhap:</label>
				<input type="text" name="user" id="user" class="form-control" required />
			</div>
			<div>
				<label for="newPassword">Mat khau moi:</label>
				<input type="password" name="newPassword" id="newPassword" class="form-control" required />
			</div>
			<div>
				<label for="confirmPassword">Xac nhan mat khau moi:</label>
				<input type="password" name="confirmPassword" id="confirmPassword" required />
			</div>
			<button type="submit">Luu thay doi</button>
		</form>

	</div>
</body>
</html>