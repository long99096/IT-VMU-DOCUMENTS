<?php
	include('connect.php');
	if(!empty($_POST['submit'])){
		if(isset($_POST['id'])&&isset($_POST['hoten'])&&isset($_POST['anhnv'])&&isset($_POST['ngaysinh'])&&isset($_POST['dienthoai'])){
			$id = $_POST['id'];
			$hoten = $_POST['hoten'];
			$anhnv = $_POST['anhnv'];
			$ngaysinh = $_POST['ngaysinh'];
			$dienthoai = $_POST['dienthoai'];
			$sql = "INSERT INTO nhanvien(id, hoten, anhnv, ngaysinh, dienthoai) VALUES('$id', '$hoten', '$anhnv','$ngaysinh', '$dienthoai')";
			$stmt = $conn->prepare($sql);
			$query = $stmt->execute();
			if ($query) { 
				header("location:index.php");
			}
			else{
				echo("Them that bai, vui long thu lai");
			}
		}
	}
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
	<title>Them nhan vien</title>
</head>
<body>
	<div>
		<table class="table table-inverse">
			<form method="POST">
			<tbody>
				<tr>
					<td>Nhap id</td>
					<td><input type="text" name="id"></td>
				</tr>

				<tr>
					<td>Nhap ho ten</td>
					<td><input type="text" name="hoten"></td>
				</tr>

				<tr>
					<td>Nhap anhnv</td>
					<td><input type="text" name="anhnv"></td>
				</tr>

				<tr>
					<td>Nhap ngaysinh</td>
					<td><input type="text" name="ngaysinh"></td>
				</tr>

				<tr>
					<td>Nhap sdt</td>
					<td><input type="text" name="dienthoai"></td>
				</tr>
				
			</tbody>
		</table>
		<button type="submit" name="submit" value="submit">Luu</button>
	</div>
	</form>
</body>
</html>