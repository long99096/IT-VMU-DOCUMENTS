<?php
    include("connect.php");
    session_start();

    if ($_SERVER['REQUEST_METHOD'] == "POST") {
        $username = $_POST['txtUsername'];
        $password = $_POST['txtPassword'];
        $sql = "SELECT * FROM login WHERE user = '$username' AND password = '$password' ";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($result) {
            $_SESSION['user'] = $username;
            header("location:index.php");
            exit();
        }
        else{
            $error = "Sai ten dang nhap hoac mat khau";
        }
    }
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dang nhap</title>
</head>
<script>
    function toggle_password() {
        const passwordField = document.getElementById('txtPassword');
        const showpassWordcheckbox = document.getElementById('showPassword');
        if (showpassWordcheckbox.checked) {
            passwordField.type = 'text';
        }
        else{
            passwordField.type = 'password';
        }
    }
</script>
<body>
    <div>
        <h2>Dang nhap</h2>
        <?php 
            if (isset($error)) {
                echo "<div class='alert alert-danger'>$error</div>";
            }
        ?>
        <form method="POST">
            <div>
                <label for="txtUsername">Ten dang nhap</label>
                <input type="text" name="txtUsername" required/>
            </div>
            <div>
                <label for= "txtPassword">Mat Khau </label>
                <input type="password" name="txtPassword" id="txtPassword" required>
            </div>
            <div>
                <input type="checkbox" id="showPassword" onclick="toggle_password()"/>
                <label for="showPassword">hien mat khau</label>
            </div>
            <button type="submit">Dang nhap</button>
        </form>
        <form action="changePassword.php" method="get">
        <button type="submit">Doi mat khau</button>
        </form>
    </div>

</body>
</html>