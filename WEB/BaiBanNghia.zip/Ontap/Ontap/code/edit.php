<?php
    include('connect.php');
    $id = $_GET['id'];
    $sql1 = "SELECT * FROM dienthoai WHERE id = '$id'";
    $stmt = $conn->prepare($sql1);
    $query = $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    if(!empty($_POST['submit'])){
        if(!empty($_POST['ten'])&&isset($_POST['anh'])&&isset($_POST['gia'])&&isset($_POST['soluong'])){
            $tenSP = $_POST['ten'];
            $anhSP = $_POST['anh'];
            $giaSP = $_POST['gia'];
            $soluongSP = $_POST['soluong'];
            $sql = "UPDATE dienthoai SET ten = '$tenSP', anh = '$anhSP', gia = '$giaSP', soluong = '$soluongSP' WHERE id = '$id' ";
            $stmt = $conn->prepare($sql);
            $query = $stmt->execute();
            if($query){
                header("location:index1.php");
            }
            else{
                echo "Them that bai, vui long thu lai";
            }
        }
    }
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <title>Sua thong tin</title>
</head>
<body>
    <div class="container">
        <form method="post">
            <table class="table table-inverse">
                <tbody>
                    <tr>
                        <td>Nhap ten san pham</td>
                        <td><input type="text" name="ten" value="<?php echo $result['ten'] ?>"></td>
                    </tr>

                    <tr>
                        <td>Nhap anh san pham</td>
                        <td><input type="text" name="anh" value="<?php echo $result['anh'] ?>"></td>
                    </tr>

                    <tr>
                        <td>Nhap gia san pham</td>
                        <td><input type="text" name="gia" value="<?php echo $result['gia'] ?>"></td>
                    </tr>

                    <tr>
                        <td>Nhap so luong san pham</td>
                        <td><input type="text" name="soluong" value="<?php echo $result['soluong'] ?>"></td>
                    </tr>

                </tbody>
            </table>
            <button type="submit" name="submit" value="submit"> Luu</button>
        </form>
    </div>
</body>
</html>