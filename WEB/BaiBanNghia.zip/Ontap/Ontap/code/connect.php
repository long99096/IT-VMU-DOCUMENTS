<?php
	$conn = new PDO('mysql:host=localhost; dbname=cuahang','root','');
	if($conn){
		//echo "Connected successfully";
	}
	else{
		echo "Connection failed";
	}

?>