<?php
	include 'connect.php';
	$sql = "SELECT * FROM dienthoai";
	$stmt = $conn->prepare($sql);
	$query = $stmt->execute();
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  	<link rel="stylesheet" type="text/css" href="style.css?v=1.">
	<title>Cua Hang</title>
</head>
<body>
	<div id = "header"><h1>SẢN PHẨM NỔI BẬT</h1></div>

	<div id="product-contain">
		
		<div id="timkiem">
			<label>Tên sản Phẩm</label>
			<input type="text" name="timkiem" class="search-bar">
			<button class="btn btn-success" type="button" name="btnTimkiem">Tìm kiếm</button>
			<form action="add_sanpham.php" method="get"  >
				<button type="submit" name="btnAdd" value="themsanpham" class="btn btn-warning">Them San Pham</button>
			</form>
			<form action="logout.php" method="get">
				<button action="logout" name="btnDangxuat" value="dangxuat" class="btn btn-danger">Dang xuat</button>
				
			</form>
		</div>
		
			<table border="1" class= "table table-bordered">
				<tr>
					<?php
					if($query){
						$count = 0;
						while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
								if ($count == 4) {
	                        echo "</tr><tr>"; 
	                        $count = 0;
	                    		}
							?>
							<td>
								<div class="product">
									<h3><?php echo $row['ten']?></h3>
									<img style="width: 100px" src="../image/<?php echo $row['anh'];?>">
									<p>Giá: <?php echo $row['gia']?></p>
									<p>Số lượng: <?php echo $row['soluong']?></p>

									<div class="action-button">
										<form action="edit.php" method="get">
											<input type="hidden" name="id" value="<?php echo $row['id']; ?>">
											<button type="submit" name="btnSua" value="Sua" class="btn btn-info">Sua</button>
										</form>
										<form action="delete.php" method="get">
											<input type="hidden" name="id" value="<?php echo $row['id'] ?>">
											<button type="submit" name="btnXoa" value="Xoa" class="btn btn-info">Xoa</button>
										</form>
									</div>
								</div>
							</td>
							<?php
							$count++;
							}
						}
					?>
				</tr>
			</table>
				
	</div>

	</body>
</html>