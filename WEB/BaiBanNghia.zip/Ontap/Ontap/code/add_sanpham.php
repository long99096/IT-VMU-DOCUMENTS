<?php
include("connect.php");
if(!empty($_POST['submit'])){
	if(isset($_POST['ten'])&&isset($_POST['anh'])&&isset($_POST['gia'])&&isset($_POST['soluong'])){
		$tenSP = $_POST['ten'];
		$anh = $_POST['anh'];
		$giaSP = $_POST['gia'];
		$soluongSP = $_POST['soluong'];
		$sql = "INSERT INTO dienthoai(ten, anh, gia, soluong) VALUES('$tenSP', '$anh', '$giaSP', '$soluongSP')";
		$stmt = $conn->prepare($sql);
		$query = $stmt->execute();
		if($query){
			header("location:index1.php");
		}
		else{
			echo"Them that bai, vui long thu lai!";
		}
	}
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
	<title>Them sinh vien</title>
</head>
<body>
	<div class="container">
		<form method="post">
			<table class="table table-inverse">
				<tbody>
					<tr>
						<td>Nhap ten san pham</td>
						<td><input type="text" name="ten"></td>
					</tr>

					<tr>
						<td>Them anh</td>
						<td><input type="text" name="anh"></td>
					</tr>

					<tr>
						<td>Nhap gia san pham</td>
						<td><input type="text" name="gia"></td>
					</tr>

					<tr>
						<td>Nhap so luong san pham</td>
						<td><input type="text" name="soluong"></td>
					</tr>

				</tbody>
			</table>
			<button type="submit" name="submit" value="submit">Luu</button>
		</form>
	</div>
</body>
</html>