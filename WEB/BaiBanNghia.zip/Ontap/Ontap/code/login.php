<?php
	include('connect.php');
	session_start();

	if ($_SERVER["REQUEST_METHOD"] == "POST") {
		$username = $_POST['txtUsername'];
		$password = $_POST['txtPassword'];
		$sql = "SELECT * FROM login WHERE username = '$username' AND password = '$password' ";
		$stmt = $conn->prepare($sql);
		$stmt->execute();
		$result = $stmt->fetch(PDO::FETCH_ASSOC);

		if ($result) {
			$_SESSION['username'] = $username;
			header("location: index1.php");
			exit();
		}
		else{
			$error = "Sai ten dang nhap hoac mat khau";
		}
	}
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
	<title>Session</title>
</head>
<script>
	function togglePassword(){
		const passwordField = document.getElementById('txtPassword');
		const showPasswordCheckbox = document.getElementById('showPassword');
		if (showPasswordCheckbox.checked) {
			passwordField.type = 'text';
		}
		else {
			passwordField.type = 'password';
		}
	}
</script>
<body>
	<div>
		<h2>Dang nhap</h2>
		<?php
			if(isset($error)){
				echo "<div class='alert alert-danger'>$error</div>";
			}
		?>
		<form name="frmLogin" action="" method = "post">
			<div>
				<label for="txtUsername" class="form-label">Ten dang nhap</label>
				<input type="text" name="txtUsername" required />
			</div>
			<div>
				<label for="txtPassword">Mat khau</label>
				<input type="password" name="txtPassword" id="txtPassword" required />
			</div>
			<div>
				<input type="checkbox" id="showPassword" onclick="togglePassword()" />
				<label for = "showPassword">Hien thi mat khau</label>
			</div>
			<button type="submit">Dang nhap</button>
		</form>
		<a href="changePassword.php">Doi mat khau</a>
	</div>
</body>
</html>